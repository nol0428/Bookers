class List < ApplicationRecord
end
